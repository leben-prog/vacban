data class Requests(
    val id: Int,
    val category: String,
    val departureDate: String,
    val arrivalDate: String,
    val status: String
)
