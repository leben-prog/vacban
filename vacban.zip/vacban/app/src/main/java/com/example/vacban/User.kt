data class User(
    val login: String,
    val name: String,
    val pass: String
)
